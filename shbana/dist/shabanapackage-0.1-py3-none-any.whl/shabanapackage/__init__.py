s=lambda arg:len(arg)
mylist=['I','Love','Pakistan']
rv=s(mylist)
rv
 
s=lambda s:s[0]
res=s("shabana")
res


s=lambda arg:len(arg)
mylist=['I','Love','Pakistan']
rv=s(mylist)
rv